package com.example.EmployeeManagementSystem;

public interface EmployeeProjection {
    Long getId();
    String getName();
    String getEmail();
    Department getDepartment();
}
