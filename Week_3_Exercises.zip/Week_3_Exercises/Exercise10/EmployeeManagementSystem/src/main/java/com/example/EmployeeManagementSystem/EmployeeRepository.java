package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;
import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    @Transactional
    default void batchSave(List<Employee> employees) {
        int batchSize = 50;
        for (int i = 0; i < employees.size(); i++) {
            save(employees.get(i));
            if (i % batchSize == 0 && i > 0) {
                flush();
                clear();
            }
        }
        flush();
        clear();
    }

    void flush();
    void clear();
}
