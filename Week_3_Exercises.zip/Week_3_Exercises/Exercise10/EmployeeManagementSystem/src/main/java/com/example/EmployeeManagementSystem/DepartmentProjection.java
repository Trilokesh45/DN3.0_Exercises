package com.example.EmployeeManagementSystem;

public interface DepartmentProjection {
    Long getId();
    String getName();
}
