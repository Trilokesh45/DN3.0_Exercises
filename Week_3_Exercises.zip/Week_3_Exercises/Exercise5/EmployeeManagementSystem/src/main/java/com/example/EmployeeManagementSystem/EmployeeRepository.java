package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {

    // Execute the named query "Employee.findByDepartmentNameNamed"
    List<Employee> findByDepartmentNameNamed(@Param("name") String name);

    // Execute the named query "Employee.findByEmailNamed"
    Employee findByEmailNamed(@Param("email") String email);
}
