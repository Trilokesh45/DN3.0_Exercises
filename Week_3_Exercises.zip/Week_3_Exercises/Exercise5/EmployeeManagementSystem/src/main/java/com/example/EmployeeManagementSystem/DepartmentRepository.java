package com.example.EmployeeManagementSystem;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;
public interface DepartmentRepository extends JpaRepository<Department, Long> {

    // Custom query to find a department by name
    @Query("SELECT d FROM Department d WHERE d.name = :name")
    Department findByNameCustom(@Param("name") String name);

    // Custom SQL query to find departments with names starting with a specific prefix
    @Query(value = "SELECT * FROM departments WHERE name LIKE :prefix%", nativeQuery = true)
    List<Department> findByNameStartingWith(@Param("prefix") String prefix);
}
